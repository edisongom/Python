# -*- coding: utf-8 -*-
"""
Created on Thu Nov  9 18:07:13 2023

@author: yleivar
"""

import numpy as np

# Definición de la función para convertir coordenadas geodésicas a cartesianas (ECEF)
def Geoxyz(lat, lon, h,pa_elip):
    a=pa_elip[0]
    f=pa_elip[1]
    resultado=[]
    # Conversión de latitud y longitud de grados decimales a radianes
    lat_rad = np.deg2rad(lat)
    lon_rad = np.deg2rad(lon)
    
    # Primer excentricidad al cuadrado
    e2 = (f * (2 - f))
    # Radio de curvatura en el primer vertical
    N = a / np.sqrt(1 - e2 * np.sin(lat_rad)**2)
    
    # Coordenadas cartesianas
    X = (N + h) * np.cos(lat_rad) * np.cos(lon_rad)
    Y = (N + h) * np.cos(lat_rad) * np.sin(lon_rad)
    Z = ((1 - e2) * N + h) * np.sin(lat_rad)
    
    resultado.append(X)
    resultado.append(Y)
    resultado.append(Z)
    
    return resultado



    
