# -*- coding: utf-8 -*-
"""
Created on Wed Sep  6 12:10:13 2023

@author: yleivar
"""
import math as m
import numpy as np

#pa_elip = [6378137, 6356752.31424518]  # elipsoide grs-80, valores de a y b

#mat_XYZ = [1756025.55120742, -5025815.15556252, -3501691.52467817]
             
def XYZ_Geo(mat_XYZ, elip_out):
    a = elip_out[0]
    f = elip_out[1]
    e2 = 2*f-f**2 # Excentricidad al cuadrado

    r_XY = m.sqrt(mat_XYZ[0]**2 + mat_XYZ[1]**2)  # Distancia desde el eje Z

    # Latitud geocéntrica preliminar
    phi_p = m.atan2(mat_XYZ[2], r_XY * (1 - f))

    # Define un umbral de convergencia
    epsilon = 0.00000002  # Precisión hasta el nivel de los centímetros.... 0 0 0.0001 TRANSFORMAR A RADIANES Y VER SI MI UMBRAL ESTA BIEN

    phi =np.radians(phi_p)  # Inicializar la latitud geodésica con el valor preliminar
    delta = 1  # Una diferencia inicial grande para iniciar el bucle
    iterations = 0
    max_iterations = 1000  # Establece un límite para evitar bucles infinitos

    while delta > epsilon and iterations < max_iterations:
        N = a / m.sqrt(1 - e2 * m.sin(phi)**2)
        h = r_XY / m.cos(phi) - N
        phi_new = m.atan2(mat_XYZ[2] + e2 * N * m.sin(phi), r_XY)
        delta = abs(phi_new - phi)  # Calcula la diferencia entre las iteraciones
        phi = phi_new
        iterations += 1

    lambda_ = m.atan2(mat_XYZ[1], mat_XYZ[0])

    mat_Geo = [m.degrees(phi), m.degrees(lambda_), h]
    print(f"Convergencia en iteration: {iterations}")

    return mat_Geo




