# -*- coding: utf-8 -*-
"""
Created on Wed Sep  6 10:37:36 2023

@author: yleivar
"""
def ingresocord():
    mat_in=[]

    ingreso = input(
        '\nIngresa las coordenadas geodesicas iniciales separadas por espacio y en orden Lat long hElip : ')

    datos = ingreso.split()  # separar argumentos de lista para llevar a flotantes

    # Convertir los valores ingresados en números flotantes
    lat = float(datos[0])
    lon = float(datos[1])
    hElip = float(datos[2])
    Hso= int((lon/6)+31)
    
    mat_in.append(lat)
    mat_in.append(lon)
    mat_in.append(hElip)
    mat_in.append(Hso)

    return mat_in